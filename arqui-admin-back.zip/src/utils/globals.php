<?php

Flight::set('public', ['/login', '/servicios', '/proyectos', '/web']);